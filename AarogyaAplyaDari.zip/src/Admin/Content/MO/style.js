import { Button } from "antd";
import styled from "styled-components";

export const AddButton = styled(Button)`
  background-color: #176b87;
  color: white;
  width: 200px;
  margin: 18px 60px;
`;
export const SearchButton = styled(Button)`
  background-color: #176b87;
  color: white;
  border-radius: 20px;
  margin-left: 30px;
`;
export const EditButton = styled(Button)``;
export const DeleteButton = styled(Button)`
  background-color: #de4132;
`;
