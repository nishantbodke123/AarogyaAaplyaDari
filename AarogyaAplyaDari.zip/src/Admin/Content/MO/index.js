import { Button, Input, Spin, Table } from "antd";
import { Content } from "antd/es/layout/layout";
import axios from "axios";
import React from "react";
import { useEffect } from "react";
import { BASE_URL } from "../../../Utils/BaseURL";
import { useState } from "react";
import { LogOut } from "../../../Auth/Logout";
import moment from "moment/moment";
import { AddButton, DeleteButton, EditButton, SearchButton } from "./style";

function MO() {
  const [MOData, setMOData] = useState([]);
  const [loader, setLoader] = useState(false);
  useEffect(() => {
    setLoader(true);
    axios
      .get(`${BASE_URL}/adminportal/api/GetuserListAPI/mo`)
      .then((res) => {
        setLoader(false);
        console.log(res.data.data);
        setMOData(res.data.data);
      })
      .catch((error) => {
        setLoader(false);
        console.log(error);
        if (error.status == "401") {
          setTimeout(() => {
            LogOut();
          }, 1000);
        }
      });
  }, []);

  const column = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "User Name",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email ID",
      dataIndex: "emailId",
    },
    {
      title: "Phone Number",
      dataIndex: "phoneNumber",
    },
    {
      title: "Section",
      dataIndex: "section",
    },
    {
      title: "Date & Time Of Joining",
      dataIndex: "date_joined",
      render: (date) => {
        return moment(date).format("DD/MM/YYYY h:mm:ss a");
      },
    },
    {
      title: "Update",
      render: () => {
        return <EditButton>Edit</EditButton>;
      },
    },
    {
      title: "Delete",
      render: () => {
        return <DeleteButton>Delete</DeleteButton>;
      },
    },
  ];
  return (
    <Spin spinning={loader}>
      <>
        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            minHeight: "81.9Vh",
            background: "white",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              margin: "20px 0px",
            }}
          >
            <p
              style={{
                fontSize: "25px",
                fontWeight: 750,
                fontFamily: "sans-serif",
                color: "#176b87",
              }}
            >
              Medical Officers (MO)
            </p>
            <AddButton>Add MO</AddButton>
          </div>
          <div>
            <div style={{ margin: "20px 10px" }}>
              <Input
                type="text"
                style={{ width: "300px" }}
                placeholder="Enter Name / User Name / ward "
              ></Input>
              <SearchButton>Search</SearchButton>
            </div>
            <Table columns={column} dataSource={MOData}></Table>
          </div>
        </Content>
      </>
    </Spin>
  );
}
export default MO;
