import {
  Button,
  Col,
  Form,
  Input,
  Modal,
  Row,
  Select,
  Spin,
  Table,
  message,
} from "antd";
import { Content } from "antd/es/layout/layout";
import axios from "axios";
import React from "react";
import { useEffect } from "react";
import { BASE_URL } from "../../../Utils/BaseURL";
import { useState } from "react";
import { LogOut } from "../../../Auth/Logout";
import moment from "moment/moment";
import { EditOutlined } from "@ant-design/icons";
import {
  AddButton,
  CancelButton,
  DeleteButton,
  EditButton,
  InputBox,
  PasswordUpdateButton,
  SearchButton,
  SubmitButton,
  UpdateButton,
} from "./style";
import FormItem from "antd/es/form/FormItem";
import { Option } from "antd/es/mentions";

function MO() {
  const [refresh, setRefresh] = useState(1);
  useEffect(() => {
    setLoader(true);
    axios
      .get(`${BASE_URL}/adminportal/api/GetuserListAPI/mo`)
      .then((res) => {
        setLoader(false);
        console.log(res.data.data);
        setMOData(res.data.data);
      })
      .catch((error) => {
        setLoader(false);
        console.log(error);
        if (error.status == "401") {
          setTimeout(() => {
            LogOut();
          }, 1000);
        }
      });
  }, [refresh]);
  //generic State
  const [wardList, setWardList] = useState([]);
  const [MOData, setMOData] = useState([]);
  const [List, setHealthPostNameList] = useState([]);
  const [dispensaryList, setDispensaryList] = useState([]);
  const [loader, setLoader] = useState(false);
  const [addMOModal, setAddMOModal] = useState(false);
  const [changePasswordModal, setChangePasswordModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [searchValue, setSearchValue] = useState();

  //Add User State
  const [name, setName] = useState();
  const [userName, setUserName] = useState();
  const [password, setPassword] = useState();
  const [confirmPassword, setConfirmPassword] = useState();
  const [phoneNumber, setPhoneNumber] = useState();
  const [email, setEmail] = useState();
  const [dispensary, setDispensary] = useState();
  const [MOid, setMOid] = useState();

  //Edit Modal State
  const [u_name, setU_name] = useState();
  const [u_userName, setU_userName] = useState();
  const [u_phoneNumber, setU_phoneNumber] = useState();
  const [u_email, setU_email] = useState();
  const [u_ward, setU_ward] = useState();
  const [u_healthPost, setU_HealthPost] = useState();
  const [u_Dispensary, setU_Dispensary] = useState();

  const handleU_NameChange = (e) => {
    const regex = /^[ a-zA-Z]+$/;
    if (e.target.value === "" || regex.test(e.target.value)) {
      setU_name(e.target.value);
    }
  };
  const handleU_UserNameChange = (e) => {
    const regex = /^[ a-zA-Z0-9@]+$/;
    if (e.target.value === "" || regex.test(e.target.value)) {
      setU_userName(e.target.value);
    }
  };
  const handleU_MobileNumberChange = (e) => {
    const regex = /^[0-9]{1,10}$/;
    if (e.target.value === "" || regex.test(e.target.value)) {
      setU_phoneNumber(e.target.value);
    }
  };

  //change password state
  const [newPassword, setNewPassword] = useState();
  const [confirmNewPassword, setConfirmNewPassword] = useState();

  const handleNameChange = (e) => {
    const regex = /^[ a-zA-Z]+$/;
    if (e.target.value === "" || regex.test(e.target.value)) {
      setName(e.target.value);
    }
  };
  const handleUserNameChange = (e) => {
    const regex = /^[ a-zA-Z0-9@]+$/;
    if (e.target.value === "" || regex.test(e.target.value)) {
      setUserName(e.target.value);
    }
  };
  const handleMobileNumberChange = (e) => {
    const regex = /^[0-9]{1,10}$/;
    if (e.target.value === "" || regex.test(e.target.value)) {
      setPhoneNumber(e.target.value);
    }
  };
  const handleSearch = () => {
    setLoader(true);
    axios
      .get(`${BASE_URL}/adminportal/api/GetuserListAPI/mo`, {
        params: {
          search: searchValue,
        },
      })
      .then((res) => {
        setLoader(false);
        console.log(res.data.data);
        setMOData(res.data.data);
      })
      .catch((error) => {
        setLoader(false);
        console.log(error);
        if (error.status == "401") {
          setTimeout(() => {
            LogOut();
          }, 1000);
        }
      });
  };

  const handleMOModalView = () => {
    axios
      .get(`${BASE_URL}/allauth/api/GetWardListAPI`, {
        headers: {
          Authorization: `Token ${sessionStorage.getItem("Token")}`,
        },
      })
      .then((res) => {
        console.log(res.data);
        setWardList(res.data);
      })
      .catch((err) => {
        console.log(err);
        if (err.status == 401) {
          setTimeout(() => {
            LogOut();
          }, 1000);
        }
      });
    setAddMOModal(true);
  };
  const handleWardSelect = (id) => {
    setU_ward(id);
    setDispensaryList([]);
    setU_Dispensary();
    axios
      .get(`${BASE_URL}/allauth/api/GetDispensaryListAPI/${id}`, {
        headers: {
          Authorization: `Token ${sessionStorage.getItem("Token")}`,
        },
      })
      .then((res) => {
        console.log(res.data);
        setDispensaryList(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleMOModalClose = () => {
    setName();
    setUserName();
    setEmail();
    setPassword();
    setConfirmPassword();
    setPhoneNumber();
    setDispensary();
    setAddMOModal(false);
  };
  let axiosConfig = {
    headers: {
      "Content-Type": "multipart/form-data",
      Authorization: `Token ${sessionStorage.getItem("Token")}`,
    },
  };

  const handleEditModalShow = (data) => {
    console.log(data);
    axios
      .get(`${BASE_URL}/allauth/api/GetWardListAPI`, {
        headers: {
          Authorization: `Token ${sessionStorage.getItem("Token")}`,
        },
      })
      .then((res) => {
        console.log(res.data);
        setWardList(res.data);
        axios
          .get(`${BASE_URL}/allauth/api/GetDispensaryListAPI/${data.ward_id}`, {
            headers: {
              Authorization: `Token ${sessionStorage.getItem("Token")}`,
            },
          })
          .then((res) => {
            console.log(res.data);
            setDispensaryList(res.data);
          })
          .catch((err) => {
            console.log(err);
          });
      })
      .catch((err) => {
        console.log(err);
        if (err.status == 401) {
          setTimeout(() => {
            LogOut();
          }, 1000);
        }
      });
    setMOid(data.id);
    setU_name(data.name);
    setU_userName(data.username);
    setU_phoneNumber(data.phoneNumber);
    setU_email(data.emailId);
    setU_ward(data.ward_id);
    // handleWardSelect(data.ward_id);
    setU_HealthPost(data.health_Post_id);
    // handleHealthPostSelect(data.health_Post_id);
    setU_Dispensary(data.dispensary);
    setShowEditModal(true);
  };
  const handleEditModalClose = () => {
    setU_name();
    setU_userName();
    setU_phoneNumber();
    setU_email();
    setU_ward();
    setU_HealthPost();
    setU_Dispensary();

    setShowEditModal(false);
  };

  const handleAddUser = () => {
    let formData = new FormData();
    formData.append("name", name);
    formData.append("username", userName);
    formData.append("password", password);
    formData.append("phoneNumber", phoneNumber);
    formData.append("emailId", email);
    formData.append("dispensary", dispensary);
    formData.append("group", "mo");
    if (password !== confirmPassword) {
      message.warning("The passwords doesn't match");
    } else {
      axios
        .post(`${BASE_URL}/adminportal/api/InsertUsers`, formData, axiosConfig)
        .then((res) => {
          console.log(res.data.message);
          message.success(res.data.message);
          setRefresh(refresh + 1);
          handleMOModalClose();
        })
        .catch((err) => {
          console.log(err);
          message.warning(err.response.data.message);
        });
    }
  };
  const handleUpdateUser = () => {
    console.log(MOid);
    if (u_name === "") {
      message.warning(" Please Enter Name");
    } else if (u_userName === "") {
      message.warning(" Please Enter Username");
    } else if (u_email === "") {
      message.warning("Please Enter Email Address");
    } else if (u_phoneNumber === "") {
      message.warning("Please Enter Phone Number");
    } else if (u_Dispensary === undefined) {
      message.warning("Please select Dispensary");
    } else {
      const formData = new FormData();
      formData.append("name", u_name);
      formData.append("username", u_userName);
      formData.append("emailId", u_email);
      formData.append("phoneNumber", u_phoneNumber);
      formData.append("dispensary", u_Dispensary);

      axios
        .patch(
          `${BASE_URL}/adminportal/api/UpdateUserDetailsAPI/${MOid}`,
          formData,
          axiosConfig
        )
        .then((res) => {
          console.log(res);
          message.success(res.data.message);
          setRefresh(refresh + 1);
          handleEditModalClose();
        })
        .catch((err) => {
          console.log(err);
          message.warning(err.response.data.message);
        });
    }
  };
  const deleteUser = (data) => {
    Modal.confirm({
      title: `Do you want to Remove user ${data.name}`,
      okText: "Confirm",
      onOk: () => {
        axios
          .delete(`${BASE_URL}/adminportal/api/deleteUserAPI/${data.id}`, {
            headers: {
              Authorization: `Token ${sessionStorage.getItem("Token")}`,
            },
          })
          .then((res) => {
            console.log(res);
            message.success(res.data.message);
            setRefresh(refresh + 1);
          })
          .catch((err) => {
            console.log(err);
            message.warning(err.response.data.message);
          });
      },
    });
  };

  const handleChangePasswordModalView = (id) => {
    setMOid(id);
    setChangePasswordModal(true);
  };
  const handleChangePasswordModalClose = () => {
    setNewPassword();
    setConfirmNewPassword();
    setMOid();
    setChangePasswordModal(false);
  };
  const handlePasswordUpdate = () => {
    console.log(newPassword, MOid);
    if (newPassword === confirmNewPassword) {
      axios
        .patch(
          `${BASE_URL}/adminportal/api/AdminChangePasswordView/${MOid}`,
          {
            newpassword: newPassword,
          },
          axiosConfig
        )
        .then((res) => {
          console.log(res);
          message.success(res.data.message);
          setRefresh(refresh + 1);
          handleChangePasswordModalClose();
        })
        .catch((err) => {
          console.log(err);
          message.warning(err.response.data.message);
        });
    } else {
      message.warning("Enter same password");
    }
  };

  const column = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "User Name",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "Email ID",
      dataIndex: "emailId",
    },
    {
      title: "Phone Number",
      dataIndex: "phoneNumber",
    },
    {
      title: "Ward",
      dataIndex: "ward",
    },
    {
      title: "Dispensary",
      dataIndex: "dispensary",
    },
    {
      title: "Date & Time Of Joining",
      dataIndex: "date_joined",
      render: (date) => {
        return moment(date).format("DD/MM/YYYY h:mm:ss a");
      },
    },
    {
      title: "Update",
      render: (data) => {
        return (
          <EditButton onClick={() => handleEditModalShow(data)}>
            Edit
          </EditButton>
        );
      },
    },
    {
      title: "Delete",
      render: (data) => {
        return (
          <DeleteButton onClick={() => deleteUser(data)}>Delete</DeleteButton>
        );
      },
    },
    {
      title: "Password",
      render: (data) => {
        return (
          <Button
            style={{ border: "none" }}
            onClick={() => handleChangePasswordModalView(data.id)}
          >
            <EditOutlined />
          </Button>
        );
      },
    },
  ];
  return (
    <Spin spinning={loader}>
      <>
        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            minHeight: "81.9Vh",
            background: "white",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              margin: "20px 0px",
            }}
          >
            <p
              style={{
                fontSize: "25px",
                fontWeight: 750,
                fontFamily: "sans-serif",
                color: "#176b87",
              }}
            >
              Medical Officers (MO)
            </p>
            <AddButton onClick={handleMOModalView}>Add MO</AddButton>
          </div>
          <div>
            <div style={{ margin: "20px 10px" }}>
              <Form>
                <FormItem>
                  <Input
                    type="text"
                    style={{ width: "300px" }}
                    placeholder="Enter Name / User Name / ward "
                    onChange={(e) => setSearchValue(e.target.value)}
                  ></Input>

                  <SearchButton htmlType="submit" onClick={handleSearch}>
                    Search
                  </SearchButton>
                </FormItem>
              </Form>
            </div>
            <Table columns={column} dataSource={MOData}></Table>
          </div>
          <Modal
            open={addMOModal}
            width={900}
            onCancel={handleMOModalClose}
            title={
              <div>
                <h3>Medical Officer details</h3>
              </div>
            }
            footer={
              <>
                <CancelButton onClick={handleMOModalClose}>Cancel</CancelButton>
                <SubmitButton onClick={handleAddUser}>Submit</SubmitButton>
              </>
            }
          >
            <Form layout="vertical">
              <Row>
                <Col span={12}>
                  <FormItem label="Name">
                    <InputBox
                      type="text"
                      value={name}
                      onChange={(e) => handleNameChange(e)}
                    ></InputBox>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Username">
                    <InputBox
                      type="text"
                      allowClear
                      value={userName}
                      onChange={(e) => handleUserNameChange(e)}
                    ></InputBox>
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={12}>
                  <FormItem label="Enter Password">
                    <Input.Password
                      type="text"
                      value={password}
                      style={{ width: "350px" }}
                      onChange={(e) => setPassword(e.target.value)}
                    ></Input.Password>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Confirm Password">
                    <Input.Password
                      type="text"
                      value={confirmPassword}
                      style={{ width: "350px" }}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    ></Input.Password>
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={12}>
                  <FormItem label="Phone Number">
                    <InputBox
                      type="text"
                      value={phoneNumber}
                      onChange={(e) => handleMobileNumberChange(e)}
                    ></InputBox>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Email ID">
                    <InputBox
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    ></InputBox>
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={12}>
                  {" "}
                  <FormItem label="Ward">
                    <Select
                      showSearch
                      style={{ width: "350px" }}
                      filterOption={(inputValue, option) =>
                        option.children
                          ? option.children
                              .toLowerCase()
                              .includes(inputValue.toLowerCase())
                          : false
                      }
                      onChange={(e) => handleWardSelect(e)}
                    >
                      {wardList.map((data) => (
                        <Option key={data.id} value={data.id}>
                          {data.wardName}
                        </Option>
                      ))}
                    </Select>
                  </FormItem>
                </Col>
                <Col>
                  <FormItem label="Dispensary">
                    <Select
                      showSearch
                      style={{ width: "350px" }}
                      filterOption={(inputValue, option) =>
                        option.children
                          ? option.children
                              .toLowerCase()
                              .includes(inputValue.toLowerCase())
                          : false
                      }
                      onChange={(e) => setDispensary(e)}
                    >
                      {dispensaryList.map((data) => (
                        <Option key={data.id} value={data.id}>
                          {data.dispensaryName}
                        </Option>
                      ))}
                    </Select>
                  </FormItem>
                </Col>
              </Row>
            </Form>
          </Modal>
          <Modal
            open={changePasswordModal}
            onCancel={handleChangePasswordModalClose}
            footer={
              <>
                <Button onClick={handleChangePasswordModalClose}>Cancel</Button>
                <PasswordUpdateButton onClick={handlePasswordUpdate}>
                  Update
                </PasswordUpdateButton>
              </>
            }
          >
            <Form layout="vertical">
              <FormItem label="New Password">
                <Input.Password
                  style={{ width: "350px" }}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                ></Input.Password>
              </FormItem>
              <FormItem label="confirm new Password">
                <Input.Password
                  style={{ width: "350px" }}
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                ></Input.Password>
              </FormItem>
            </Form>
          </Modal>
          <Modal
            open={showEditModal}
            title={<h2>Update MO's Details</h2>}
            width={1000}
            onCancel={handleEditModalClose}
            footer={
              <>
                <Button onClick={handleEditModalClose}>Cancel</Button>
                <UpdateButton onClick={handleUpdateUser}>Update</UpdateButton>
              </>
            }
          >
            <Form layout="vertical">
              <Row>
                <Col span={12}>
                  <FormItem label="Name">
                    <InputBox
                      type="text"
                      value={u_name}
                      onChange={(e) => handleU_NameChange(e)}
                    ></InputBox>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Username">
                    <InputBox
                      type="text"
                      allowClear
                      value={u_userName}
                      onChange={(e) => handleU_UserNameChange(e)}
                    ></InputBox>
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={12}>
                  <FormItem label="Phone Number">
                    <InputBox
                      type="text"
                      value={u_phoneNumber}
                      onChange={(e) => handleU_MobileNumberChange(e)}
                    ></InputBox>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Email ID">
                    <InputBox
                      type="email"
                      value={u_email}
                      onChange={(e) => setU_email(e.target.value)}
                    ></InputBox>
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={12}>
                  <FormItem label="Ward">
                    <Select
                      showSearch
                      style={{ width: "350px" }}
                      filterOption={(inputValue, option) =>
                        option.children
                          ? option.children
                              .toLowerCase()
                              .includes(inputValue.toLowerCase())
                          : false
                      }
                      value={u_ward}
                      onChange={(e) => handleWardSelect(e)}
                    >
                      {wardList.map((data) => (
                        <Option key={data.id} value={data.id}>
                          {data.wardName}
                        </Option>
                      ))}
                    </Select>
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="Dispensary">
                    <Select
                      showSearch
                      style={{ width: "350px" }}
                      filterOption={(inputValue, option) =>
                        option.children
                          ? option.children
                              .toLowerCase()
                              .includes(inputValue.toLowerCase())
                          : false
                      }
                      value={u_Dispensary}
                      onChange={(e) => setU_Dispensary(e)}
                    >
                      {dispensaryList.map((data) => (
                        <Option key={data.id} value={data.id}>
                          {data.dispensaryName}
                        </Option>
                      ))}
                    </Select>
                  </FormItem>
                </Col>
              </Row>
            </Form>
          </Modal>
        </Content>
      </>
    </Spin>
  );
}
export default MO;
