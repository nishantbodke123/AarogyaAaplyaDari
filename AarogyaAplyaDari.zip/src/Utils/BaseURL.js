//server internal
// export const BASE_URL = "http://172.16.0.40:9061";
//server external
export const BASE_URL = "http://202.189.224.222:9061";
// export const BASE_URL = "http://10.202.100.236:9061";

//jafar's system
// export const BASE_URL = "http://10.202.100.224:9061";
