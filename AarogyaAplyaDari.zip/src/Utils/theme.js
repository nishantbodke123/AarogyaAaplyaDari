export const theme = {
  BG_COLOR: {
    Header_Background: "",
    Button_Background: "#ff8551",
    White_Color: "#FFF6F6",
    QuestionRow_Background: "#dde6ed",
    Tab_Color : "#ff8551"
  },
};
