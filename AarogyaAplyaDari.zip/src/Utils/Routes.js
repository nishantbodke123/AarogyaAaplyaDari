export const COMMON_ROUTES = {
  healthworker: {
    VERIFYMOBILENUMBER: "/healthworker/api/verifyMobileNumber",
  },

  PHLEBO: {
    GETPHLEBOFAMILYMEMBERSDETAILS: "/GetPhleboFamilyMembersDetails",
  },
};
