import React, { useState } from "react";
import FamilyHead from "./FamilyHead";

import Header from "../Header/Header";
import { Divider } from "antd";

function Register() {
  return (
    <>
      <Header></Header>
      <FamilyHead></FamilyHead>
    </>
  );
}

export default Register;
