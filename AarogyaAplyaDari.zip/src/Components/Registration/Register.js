import React, { useState } from "react";
import FamilyHead from "./FamilyHead";

import Header from "../Header/Header";


function Register() {
  return (
    <>
      <Header></Header>
      <FamilyHead></FamilyHead>
    </>
  );
}

export default Register;
