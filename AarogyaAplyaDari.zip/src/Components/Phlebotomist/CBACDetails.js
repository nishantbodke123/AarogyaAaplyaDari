import React from "react";

function CBACDetails() {
  return (<>
  <h2>hello cbac details</h2>
  </>);
}
export default CBACDetails;
